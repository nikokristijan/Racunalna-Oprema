#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "oprema.h"

int main() {
    int izbor;

    do {
        printf("\n========================================\n");
        printf("     EVIDENCIJA RACUNALNE OPREME\n");
        printf("========================================\n");
        printf("  1. Dodaj opremu        (Create)\n");
        printf("  2. Prikazi svu opremu  (Read)\n");
        printf("  3. Pretrazi opremu     (Read)\n");
        printf("  4. Azuriraj opremu     (Update)\n");
        printf("  5. Obrisi opremu       (Delete)\n");
        printf("  6. Sortiraj opremu\n");
        printf("  0. Izlaz\n");
        printf("========================================\n");
        printf("Izbor: ");
        scanf("%d", &izbor);

        switch (izbor) {
        case 1: dodajOpremu();      break;
        case 2: prikaziSvuOpremu(); break;
        case 3: pretraziOpremu();   break;
        case 4: azurirajOpremu();   break;
        case 5: obrisiOpremu();     break;
        case 6: sortirajOpremu(); break;
        case 0: printf("\nDovidenja!\n"); break;
        default: printf("\nNepoznat izbor, pokusaj ponovo.\n");
        }

    } while (izbor != 0);

    return 0;
}