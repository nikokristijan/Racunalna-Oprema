﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "oprema.h"

int generirajID() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) return 1;

    int brojZapisa = 0;
    Oprema temp;

    while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
        brojZapisa++;
    }

    fclose(datoteka);
    return brojZapisa + 1;
}

void dodajOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "ab");

    if (datoteka == NULL) {
        printf("Greska pri otvaranju datoteke!\n");
        return;
    }

    Oprema nova;

    nova.id = generirajID();

    while (getchar() != '\n');

    printf("\n--- DODAVANJE NOVE OPREME ---\n");

    printf("Naziv: ");
    fgets(nova.naziv, MAX_NAZIV, stdin);
    nova.naziv[strcspn(nova.naziv, "\n")] = 0;

    printf("Kategorija (CPU/GPU/RAM/HDD/SSD/PSU): ");
    fgets(nova.kategorija, MAX_KATEGORIJA, stdin);
    nova.kategorija[strcspn(nova.kategorija, "\n")] = 0;

    printf("Proizvodac: ");
    fgets(nova.proizvodac, MAX_PROIZVODAC, stdin);
    nova.proizvodac[strcspn(nova.proizvodac, "\n")] = 0;

    printf("Cijena (EUR): ");
    scanf("%f", &nova.cijena);

    printf("Kolicina: ");
    scanf("%d", &nova.kolicina);

    fwrite(&nova, sizeof(Oprema), 1, datoteka);

    fclose(datoteka);

    printf("\nOprema uspjesno dodana! (ID: %d)\n", nova.id);
}
void ispisiZapis(Oprema* o) {
    printf("\n----------------------------------\n");
    printf("  ID:          %d\n", o->id);
    printf("  Naziv:       %s\n", o->naziv);
    printf("  Kategorija:  %s\n", o->kategorija);
    printf("  Proizvodač:  %s\n", o->proizvodac);
    printf("  Cijena:      %.2f EUR\n", o->cijena);
    printf("  Kolicina:    %d kom\n", o->kolicina);
    printf("----------------------------------\n");
}
void prikaziSvuOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) {
        printf("\nNema podataka. Dodajte opremu prvo.\n");
        return;
    }

    Oprema temp;
    int brojac = 0;

    printf("\n===== SVA OPREMA U EVIDENCIJI =====\n");

    while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
        ispisiZapis(&temp);
        brojac++;
    }

    if (brojac == 0) {
        printf("Evidencija je prazna.\n");
    }
    else {
        printf("\nUkupno zapisa: %d\n", brojac);
    }

    fclose(datoteka);
}

void pretraziOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) {
        printf("\nNema podataka.\n");
        return;
    }

    int izbor;
    printf("\nPretraga po:\n");
    printf("1. ID\n");
    printf("2. Naziv\n");
    printf("Izbor: ");
    scanf("%d", &izbor);

    Oprema temp;
    int nadeno = 0;

    if (izbor == 1) {
        int trazeniID;
        printf("Unesite ID: ");
        scanf("%d", &trazeniID);

        while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
            if (temp.id == trazeniID) {
                ispisiZapis(&temp);
                nadeno = 1;
                break;
            }
        }
    }
    else if (izbor == 2) {
        char trazeniNaziv[MAX_NAZIV];
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
        printf("Unesite naziv (ili dio naziva): ");
        fgets(trazeniNaziv, MAX_NAZIV, stdin);
        trazeniNaziv[strcspn(trazeniNaziv, "\n")] = 0;
        if (strlen(trazeniNaziv) == 0) {
            printf("\nNiste unijeli naziv.\n");
            fclose(datoteka);
            return;
        }
        while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
            if (strstr(temp.naziv, trazeniNaziv) != NULL) {
                ispisiZapis(&temp);
                nadeno++;
            }
        }
    }
    if (nadeno == 0) {
        printf("\nNista nije pronadeno.\n");
    }
    else if (izbor == 2) {
        printf("\nPronadeno zapisa: %d\n", nadeno);
    }
    fclose(datoteka);
}
int brojZapisa() {
    FILE* datoteka = fopen(DATOTEKA, "rb");
    if (datoteka == NULL) return 0;

    int broj = 0;
    Oprema temp;

    while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
        broj++;
    }

    fclose(datoteka);
    return broj;
}
void azurirajOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");
    int i, index, trazeniID;
    float tempCijena;
    int tempKol;
    char temp[MAX_NAZIV];
    char tempKat[MAX_KATEGORIJA];
    char tempPro[MAX_PROIZVODAC];

    if (datoteka == NULL) {
        printf("\nNema podataka.\n");
        return;
    }

    int ukupno = brojZapisa();

    if (ukupno == 0) {
        printf("\nEvidencija je prazna.\n");
        fclose(datoteka);
        return;
    }

    Oprema* svaOprema = (Oprema*)malloc(ukupno * sizeof(Oprema));

    if (svaOprema == NULL) {
        printf("Greska pri alokaciji memorije!\n");
        fclose(datoteka);
        return;
    }

    i = 0;
    while (fread(&svaOprema[i], sizeof(Oprema), 1, datoteka) == 1) {
        i++;
    }
    fclose(datoteka);


    prikaziSvuOpremu();

    printf("\nUnesite ID opreme koju zelite azurirati: ");
    scanf("%d", &trazeniID);

    index = -1;
    for (i = 0; i < ukupno; i++) {
        if (svaOprema[i].id == trazeniID) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("\nOprema s ID-em %d nije pronadena.\n", trazeniID);
        free(svaOprema);
        return;
    }

    printf("\nTrenutni podaci:\n");
    ispisiZapis(&svaOprema[index]);

    printf("\nUnesite nove podatke:\n");
    while (getchar() != '\n');

    printf("Naziv [%s]: ", svaOprema[index].naziv);
    fgets(temp, MAX_NAZIV, stdin);
    temp[strcspn(temp, "\n")] = 0;
    if (strlen(temp) > 0) {
        strcpy(svaOprema[index].naziv, temp);
    }

    printf("Kategorija [%s]: ", svaOprema[index].kategorija);
    fgets(tempKat, MAX_KATEGORIJA, stdin);
    tempKat[strcspn(tempKat, "\n")] = 0;
    if (strlen(tempKat) > 0) {
        strcpy(svaOprema[index].kategorija, tempKat);
    }

    printf("Proizvodac [%s]: ", svaOprema[index].proizvodac);
    fgets(tempPro, MAX_PROIZVODAC, stdin);
    tempPro[strcspn(tempPro, "\n")] = 0;
    if (strlen(tempPro) > 0) {
        strcpy(svaOprema[index].proizvodac, tempPro);
    }

    printf("Cijena [%.2f]: ", svaOprema[index].cijena);
    if (scanf("%f", &tempCijena) == 1) {
        svaOprema[index].cijena = tempCijena;
    }

    printf("Kolicina [%d]: ", svaOprema[index].kolicina);
    if (scanf("%d", &tempKol) == 1) {
        svaOprema[index].kolicina = tempKol;
    }

    datoteka = fopen(DATOTEKA, "wb");
    if (datoteka == NULL) {
        printf("\nGreska pri spremanju!\n");
        free(svaOprema);
        return;
    }

    for (i = 0; i < ukupno; i++) {
        fwrite(&svaOprema[i], sizeof(Oprema), 1, datoteka);
    }

    fclose(datoteka);
    free(svaOprema);
    printf("\nOprema uspjesno azurirana!\n");
}
void obrisiOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");
    int i, index, trazeniID;
    char potvrda;

    if (datoteka == NULL) {
        printf("\nNema podataka.\n");
        return;
    }

    int ukupno = brojZapisa();

    if (ukupno == 0) {
        printf("\nEvidencija je prazna.\n");
        fclose(datoteka);
        return;
    }

    Oprema* svaOprema = (Oprema*)malloc(ukupno * sizeof(Oprema));

    if (svaOprema == NULL) {
        printf("Greska pri alokaciji memorije!\n");
        fclose(datoteka);
        return;
    }

    i = 0;
    while (fread(&svaOprema[i], sizeof(Oprema), 1, datoteka) == 1) {
        i++;
    }
    fclose(datoteka);

    prikaziSvuOpremu();

    printf("\nUnesite ID opreme koju zelite obrisati: ");
    scanf("%d", &trazeniID);

    index = -1;
    for (i = 0; i < ukupno; i++) {
        if (svaOprema[i].id == trazeniID) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("\nOprema s ID-em %d nije pronadena.\n", trazeniID);
        free(svaOprema);
        return;
    }

    printf("\nBrisite li ovaj zapis?\n");
    ispisiZapis(&svaOprema[index]);

    printf("Jeste li sigurni? (d/n): ");
    while (getchar() != '\n');
    potvrda = getchar();

    if (potvrda != 'd' && potvrda != 'D') {
        printf("\nBrisanje otkazano.\n");
        free(svaOprema);
        return;
    }

    datoteka = fopen(DATOTEKA, "wb");
    if (datoteka == NULL) {
        printf("\nGreska pri spremanju!\n");
        free(svaOprema);
        return;
    }

    for (i = 0; i < ukupno; i++) {
        if (i == index) continue;
        fwrite(&svaOprema[i], sizeof(Oprema), 1, datoteka);
    }

    fclose(datoteka);
    free(svaOprema);
    printf("\nOprema uspjesno obrisana!\n");
}
void sortirajOpremu() {
    int ukupno = brojZapisa();
    int i, j, izbor, zamjena, trebaSzameniti;
    Oprema temp;
    FILE* datoteka;

    if (ukupno == 0) {
        printf("\nEvidencija je prazna.\n");
        return;
    }

    datoteka = fopen(DATOTEKA, "rb");
    if (datoteka == NULL) {
        printf("\nGreska pri otvaranju datoteke!\n");
        return;
    }

    Oprema* svaOprema = (Oprema*)malloc(ukupno * sizeof(Oprema));
    if (svaOprema == NULL) {
        printf("Greska pri alokaciji memorije!\n");
        fclose(datoteka);
        return;
    }

    i = 0;
    while (fread(&svaOprema[i], sizeof(Oprema), 1, datoteka) == 1) {
        i++;
    }
    fclose(datoteka);

    printf("\nSortiraj po:\n");
    printf("1. Cijeni (uzlazno)\n");
    printf("2. Cijeni (silazno)\n");
    printf("3. Nazivu (A-Z)\n");
    printf("4. Kolicini (uzlazno)\n");
    printf("Izbor: ");
    scanf("%d", &izbor);

    for (i = 0; i < ukupno - 1; i++) {
        zamjena = 0;

        for (j = 0; j < ukupno - i - 1; j++) {
            trebaSzameniti = 0;

            switch (izbor) {
            case 1:
                if (svaOprema[j].cijena > svaOprema[j + 1].cijena)
                    trebaSzameniti = 1;
                break;
            case 2:
                if (svaOprema[j].cijena < svaOprema[j + 1].cijena)
                    trebaSzameniti = 1;
                break;
            case 3:
                if (strcmp(svaOprema[j].naziv, svaOprema[j + 1].naziv) > 0)
                    trebaSzameniti = 1;
                break;
            case 4:
                if (svaOprema[j].kolicina > svaOprema[j + 1].kolicina)
                    trebaSzameniti = 1;
                break;
            default:
                printf("\nNepoznat izbor.\n");
                free(svaOprema);
                return;
            }

            if (trebaSzameniti) {
                temp = svaOprema[j];
                svaOprema[j] = svaOprema[j + 1];
                svaOprema[j + 1] = temp;
                zamjena = 1;
            }
        }

        if (zamjena == 0) break;
    }

    printf("\n===== SORTIRANA OPREMA =====\n");
    for (i = 0; i < ukupno; i++) {
        ispisiZapis(&svaOprema[i]);
    }

    free(svaOprema);
}