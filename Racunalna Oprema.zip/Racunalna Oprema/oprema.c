﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "oprema.h"

int generirajID() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) return 1;

    int brojZapisa = 0;
    Oprema temp;

    while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
        brojZapisa++;
    }

    fclose(datoteka);
    return brojZapisa + 1;
}

void dodajOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "ab");

    if (datoteka == NULL) {
        printf("Greska pri otvaranju datoteke!\n");
        return;
    }

    Oprema nova;

    nova.id = generirajID();

    while (getchar() != '\n');

    printf("\n--- DODAVANJE NOVE OPREME ---\n");

    printf("Naziv: ");
    fgets(nova.naziv, MAX_NAZIV, stdin);
    nova.naziv[strcspn(nova.naziv, "\n")] = 0;

    printf("Kategorija (CPU/GPU/RAM/HDD/SSD/PSU): ");
    fgets(nova.kategorija, MAX_KATEGORIJA, stdin);
    nova.kategorija[strcspn(nova.kategorija, "\n")] = 0;

    printf("Proizvodac: ");
    fgets(nova.proizvodac, MAX_PROIZVODAC, stdin);
    nova.proizvodac[strcspn(nova.proizvodac, "\n")] = 0;

    printf("Cijena (EUR): ");
    scanf("%f", &nova.cijena);

    printf("Kolicina: ");
    scanf("%d", &nova.kolicina);

    fwrite(&nova, sizeof(Oprema), 1, datoteka);

    fclose(datoteka);

    printf("\nOprema uspjesno dodana! (ID: %d)\n", nova.id);
}
void ispisiZapis(Oprema* o) {
    printf("\n----------------------------------\n");
    printf("  ID:          %d\n", o->id);
    printf("  Naziv:       %s\n", o->naziv);
    printf("  Kategorija:  %s\n", o->kategorija);
    printf("  Proizvođač:  %s\n", o->proizvodac);
    printf("  Cijena:      %.2f EUR\n", o->cijena);
    printf("  Kolicina:    %d kom\n", o->kolicina);
    printf("----------------------------------\n");
}
void prikaziSvuOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) {
        printf("\nNema podataka. Dodajte opremu prvo.\n");
        return;
    }

    Oprema temp;
    int brojac = 0;

    printf("\n===== SVA OPREMA U EVIDENCIJI =====\n");

    while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
        ispisiZapis(&temp);
        brojac++;
    }

    if (brojac == 0) {
        printf("Evidencija je prazna.\n");
    }
    else {
        printf("\nUkupno zapisa: %d\n", brojac);
    }

    fclose(datoteka);
}

void pretraziOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) {
        printf("\nNema podataka.\n");
        return;
    }

    int izbor;
    printf("\nPretraga po:\n");
    printf("1. ID\n");
    printf("2. Naziv\n");
    printf("Izbor: ");
    scanf("%d", &izbor);

    Oprema temp;
    int nadeno = 0;

    if (izbor == 1) {
        int trazeniID;
        printf("Unesite ID: ");
        scanf("%d", &trazeniID);

        while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
            if (temp.id == trazeniID) {
                ispisiZapis(&temp);
                nadeno = 1;
                break;
            }
        }
    }
}
 else if (izbor == 2) {
     char trazeniNaziv[MAX_NAZIV];

     int c;
     while ((c = getchar()) != '\n' && c != EOF);

     printf("Unesite naziv (ili dio naziva): ");
     fgets(trazeniNaziv, MAX_NAZIV, stdin);
     trazeniNaziv[strcspn(trazeniNaziv, "\n")] = 0;

     if (strlen(trazeniNaziv) == 0) {
         printf("\nNiste unijeli naziv.\n");
         fclose(datoteka);
         return;
     }

     while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
         if (strstr(temp.naziv, trazeniNaziv) != NULL) {
             ispisiZapis(&temp);
             nadeno++;
         }
     }
}

    if (nadeno == 0) {
        printf("\nNista nije pronađeno.\n");
    }
    else if (izbor == 2) {
        printf("\nPronadeno zapisa: %d\n", nadeno);
    }

    fclose(datoteka);
}
int brojZapisa() {
    FILE* datoteka = fopen(DATOTEKA, "rb");
    if (datoteka == NULL) return 0;

    int broj = 0;
    Oprema temp;

    while (fread(&temp, sizeof(Oprema), 1, datoteka) == 1) {
        broj++;
    }

    fclose(datoteka);
    return broj;
}
void azurirajOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) {
        printf("\nNema podataka.\n");
        return;
    }

    int ukupno = brojZapisa();

    if (ukupno == 0) {
        printf("\nEvidencija je prazna.\n");
        fclose(datoteka);
        return;
    }

    Oprema* svaOprema = (Oprema*)malloc(ukupno * sizeof(Oprema));

    if (svaOprema == NULL) {
        printf("Greska pri alokaciji memorije!\n");
        fclose(datoteka);
        return;
    }

    int i = 0;
    while (fread(&svaOprema[i], sizeof(Oprema), 1, datoteka) == 1) {
        i++;
    }
    fclose(datoteka);

    free(svaOprema);

    if (ukupno == 0) {
        printf("\nEvidencija je prazna.\n");
        return;
    }

    prikaziSvuOpremu();

    int trazeniID;
    printf("\nUnesite ID opreme koju zelite azurirati: ");
    scanf("%d", &trazeniID);

    int index = -1;
    for (int i = 0; i < ukupno; i++) {
        if (svaOprema[i].id == trazeniID) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("\nOprema s ID-em %d nije pronađena.\n", trazeniID);
        return;
    }

    printf("\nTrenutni podaci:\n");
    ispisiZapis(&svaOprema[index]);

    printf("\nUnesite nove podatke:\n");
    while (getchar() != '\n');

    printf("Naziv [%s]: ", svaOprema[index].naziv);
    char temp[MAX_NAZIV];
    fgets(temp, MAX_NAZIV, stdin);
    temp[strcspn(temp, "\n")] = 0;
    if (strlen(temp) > 0) {
        strcpy(svaOprema[index].naziv, temp);
    }

    printf("Kategorija [%s]: ", svaOprema[index].kategorija);
    char tempKat[MAX_KATEGORIJA];
    fgets(tempKat, MAX_KATEGORIJA, stdin);
    tempKat[strcspn(tempKat, "\n")] = 0;
    if (strlen(tempKat) > 0) {
        strcpy(svaOprema[index].kategorija, tempKat);
    }

    printf("Proizvođač [%s]: ", svaOprema[index].proizvodac);
    char tempPro[MAX_PROIZVODAC];
    fgets(tempPro, MAX_PROIZVODAC, stdin);
    tempPro[strcspn(tempPro, "\n")] = 0;
    if (strlen(tempPro) > 0) {
        strcpy(svaOprema[index].proizvodac, tempPro);
    }

    printf("Cijena [%.2f]: ", svaOprema[index].cijena);
    float tempCijena;
    if (scanf("%f", &tempCijena) == 1) {
        svaOprema[index].cijena = tempCijena;
    }

    printf("Kolicina [%d]: ", svaOprema[index].kolicina);
    int tempKol;
    if (scanf("%d", &tempKol) == 1) {
        svaOprema[index].kolicina = tempKol;
    }

    datoteka = fopen(DATOTEKA, "wb");
    if (datoteka == NULL) {
        printf("\nGreska pri spremanju!\n");
        return;
    }

    for (int i = 0; i < ukupno; i++) {
        fwrite(&svaOprema[i], sizeof(Oprema), 1, datoteka);
    }

    fclose(datoteka);
    printf("\nOprema uspjesno azurirana!\n");
}
void obrisiOpremu() {
    FILE* datoteka = fopen(DATOTEKA, "rb");

    if (datoteka == NULL) {
        printf("\nNema podataka.\n");
        return;
    }

    int ukupno = brojZapisa();

    if (ukupno == 0) {
        printf("\nEvidencija je prazna.\n");
        fclose(datoteka);
        return;
    }

    Oprema* svaOprema = (Oprema*)malloc(ukupno * sizeof(Oprema));

    if (svaOprema == NULL) {
        printf("Greska pri alokaciji memorije!\n");
        fclose(datoteka);
        return;
    }

    int i = 0;
    while (fread(&svaOprema[i], sizeof(Oprema), 1, datoteka) == 1) {
        i++;
    }
    fclose(datoteka);

    free(svaOprema);

    if (ukupno == 0) {
        printf("\nEvidencija je prazna.\n");
        return;
    }

    prikaziSvuOpremu();

    int trazeniID;
    printf("\nUnesite ID opreme koju zelite obrisati: ");
    scanf("%d", &trazeniID);

    int index = -1;
    for (int i = 0; i < ukupno; i++) {
        if (svaOprema[i].id == trazeniID) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("\nOprema s ID-em %d nije pronađena.\n", trazeniID);
        return;
    }

    printf("\nBrisite li ovaj zapis?\n");
    ispisiZapis(&svaOprema[index]);

    char potvrda;
    printf("Jeste li sigurni? (d/n): ");
    while (getchar() != '\n');
    potvrda = getchar();

    if (potvrda != 'd' && potvrda != 'D') {
        printf("\nBrisanje otkazano.\n");
        return;
    }

    datoteka = fopen(DATOTEKA, "wb");
    if (datoteka == NULL) {
        printf("\nGreska pri spremanju!\n");
        return;
    }

    for (int i = 0; i < ukupno; i++) {
        if (i == index) continue;
        fwrite(&svaOprema[i], sizeof(Oprema), 1, datoteka);
    }

    fclose(datoteka);
    printf("\nOprema uspjesno obrisana!\n");
}