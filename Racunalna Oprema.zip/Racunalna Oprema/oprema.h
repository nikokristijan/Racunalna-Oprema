#ifndef OPREMA_H
#define OPREMA_H
#define DATOTEKA "oprema.bin"
#define MAX_NAZIV 50
#define MAX_KATEGORIJA 30
#define MAX_PROIZVODAC 30

typedef struct {
    int   id;
    char  naziv[MAX_NAZIV];
    char  kategorija[MAX_KATEGORIJA];
    char  proizvodac[MAX_PROIZVODAC];
    float cijena;
    int   kolicina;
} Oprema;

void dodajOpremu();
void prikaziSvuOpremu();
void pretraziOpremu();
void azurirajOpremu();
void obrisiOpremu();
void ispisiZapis(Oprema* o);
int  generirajID();
int brojZapisa();
#endif